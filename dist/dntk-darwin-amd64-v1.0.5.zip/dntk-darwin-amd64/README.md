[![Travis CI](https://travis-ci.org/nnao45/dntk.svg?branch=master)](https://travis-ci.org/nnao45/dntk)
[![v1.0.5](https://img.shields.io/badge/package-v1.0.5-ff69b4.svg)](https://github.com/nnao45/dntk/releases/tag/v1.0.5)
[![license](http://img.shields.io/badge/license-MIT-red.svg?style=flat)](https://raw.githubusercontent.com/nnao45/dntk/master/LICENSE)
[![Go Report Card](https://goreportcard.com/badge/github.com/nnao45/dntk)](https://goreportcard.com/report/github.com/nnao45/dntk)

# dntk
dntk is command line's calculator, [GNU bc](https://www.gnu.org/software/bc/) wrapper.